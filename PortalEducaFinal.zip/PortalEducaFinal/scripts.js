// Menu mobile
class MobileNavbar {
    constructor(mobileMenu, navList, navLinks) {
      this.mobileMenu = document.querySelector(mobileMenu);
      this.navList = document.querySelector(navList);
      this.navLinks = document.querySelectorAll(navLinks);
      this.activeClass = "active";
  
      this.handleClick = this.handleClick.bind(this);
    }
  
    animateLinks() {
      this.navLinks.forEach((link, index) => {
        link.style.animation
          ? (link.style.animation = "")
          : (link.style.animation = `navLinkFade 0.5s ease forwards ${
              index / 7 + 0.3
            }s`);
      });
    }
  
    handleClick() {
      this.navList.classList.toggle(this.activeClass);
      this.mobileMenu.classList.toggle(this.activeClass);
      this.animateLinks();
    }
  
    addClickEvent() {
      this.mobileMenu.addEventListener("click", this.handleClick);
    }
  
    init() {
      if (this.mobileMenu) {
        this.addClickEvent();
      }
      return this;
    }
  }
  
  const mobileNavbar = new MobileNavbar(
    ".mobile-menu",
    ".nav-list",
    ".nav-list li",
  );
  mobileNavbar.init();

 // Animação de scrollagem
 document.addEventListener("DOMContentLoaded", function () {
  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target); // Para de observar depois que aparece
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.area-dev div').forEach(div => {
    observer.observe(div);
  });
});

// Controller 

function exemploEndpoint(req, res) {
  const userRole = req.user.role; // Supondo que o role esteja disponível no req.user
  if (userRole === 'docente') {
      // Funcionalidades exclusivas para docente
      res.send('Funcionalidade docente');
  } else if (userRole === 'aluno') {
      // Funcionalidades exclusivas para aluno
      res.send('Funcionalidade aluno');
  } else {
      res.status(403).send('Acesso negado');
  }
}






