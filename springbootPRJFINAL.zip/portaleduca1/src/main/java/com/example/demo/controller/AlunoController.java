package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Aluno;  // Alterado para Aluno
import com.example.demo.services.AlunoService;  // Alterado para AlunoService

@RestController
@RequestMapping("/aluno")  // Alterado para /aluno
public class AlunoController {

    private final AlunoService alunoService;  // Alterado para AlunoService

    @Autowired
    public AlunoController(AlunoService alunoService) {
        this.alunoService = alunoService;
    }

    @GetMapping("/home")
    public String paginaInicial() {
        return "index";  // Página inicial (opcional)
    }

    // Criar um novo aluno
    @PostMapping("/create")
    public Aluno createAluno(@RequestBody Aluno aluno) {
        return alunoService.saveAluno(aluno);  // Salvando Aluno
    }

    // Obter aluno por ID
    @GetMapping("/{id}")
    public ResponseEntity<Aluno> getAluno(@PathVariable Long id) {
        Aluno aluno = alunoService.getAlunoById(id);  // Buscando por ID
        if (aluno != null) {
            return ResponseEntity.ok(aluno);  // Retorna 200 OK com o aluno encontrado
        } else {
            return ResponseEntity.notFound().build();  // Retorna 404 caso não encontre
        }
    }

    // Obter todos os alunos
    @GetMapping
    public List<Aluno> getAllAlunos() {
        return alunoService.getAllAlunos();  // Buscando todos os alunos
    }

    // Excluir um aluno
    @DeleteMapping("/{id}")
    public void deleteAluno(@PathVariable Long id) {
        alunoService.deleteAluno(id);  // Deletando o aluno
    }
}
