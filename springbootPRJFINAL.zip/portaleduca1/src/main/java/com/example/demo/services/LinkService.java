package com.example.demo.services;

import com.example.demo.entities.Link;
import com.example.demo.repositories.LinkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Service
public class LinkService {

    @Autowired
    private LinkRepository linkRepository;

    private static String UPLOAD_DIRECTORY = "uploads/";

    // Método para salvar o link
    public Link saveLink(String link, String description, MultipartFile image, MultipartFile file) throws IOException {
        // Salvar arquivos no servidor
        String imagePath = saveFile(image, "images");
        String filePath = saveFile(file, "files");

        // Salvar no banco de dados
        Link newLink = new Link();
        newLink.setLink(link);
        newLink.setDescription(description);
        newLink.setImagePath(imagePath);
        newLink.setFilePath(filePath);

        return linkRepository.save(newLink);
    }

    // Método para salvar um arquivo
    private String saveFile(MultipartFile file, String subDirectory) throws IOException {
        if (file != null && !file.isEmpty()) {
            Path path = Paths.get(UPLOAD_DIRECTORY + subDirectory + "/" + file.getOriginalFilename());
            Files.createDirectories(path.getParent());  // Cria o diretório se não existir
            file.transferTo(path);
            return path.toString();
        }
        return null;
    }

    // Método para buscar todos os links
    public List<Link> getAllLinks() {
        return linkRepository.findAll();
    }

    // Método para buscar um link por ID (caso necessário)
    public Link findLinkById(Long id) {
        return linkRepository.findById(id).orElse(null);
    }
}
