package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Aluno;  // Alterado para Aluno
import com.example.demo.repositories.AlunoRepository;  // Alterado para AlunoRepository

@Service
public class AlunoService {

    private final AlunoRepository alunoRepository;  // Alterado para AlunoRepository

    @Autowired
    public AlunoService(AlunoRepository alunoRepository) {
        this.alunoRepository = alunoRepository;
    }

    // Preparando as buscas por id
    public Aluno getAlunoById(Long id) {
        return alunoRepository.findById(id).orElse(null);  // Alterado para Aluno
    }

    // Preparando a busca geral
    public List<Aluno> getAllAlunos() {
        return alunoRepository.findAll();  // Alterado para Aluno
    }

    // Salvando o Aluno
    public Aluno saveAluno(Aluno aluno) {
        return alunoRepository.save(aluno);  // Alterado para Aluno
    }

    // Excluindo o Aluno
    public void deleteAluno(Long id) {
        alunoRepository.deleteById(id);  // Alterado para Aluno
    }

    // Método para buscar Aluno por email e senha
    public Aluno findByEmailAndSenha(String email, String senha) {
        return alunoRepository.findByEmailAndSenha(email, senha);  // Alterado para Aluno
    }
}
