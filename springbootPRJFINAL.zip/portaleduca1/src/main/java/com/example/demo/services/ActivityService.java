package com.example.demo.services;

import com.example.demo.entities.Activity;
import com.example.demo.repositories.ActivityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ActivityService {

    @Autowired
    private ActivityRepository activityRepository;

    // Método para salvar a atividade
    public Activity saveActivity(Activity activity) {
        return activityRepository.save(activity);
    }

    // Método para recuperar todas as atividades
    public Iterable<Activity> getAllActivities() {
        return activityRepository.findAll();
    }
}
