package com.example.demo.services;

import com.example.demo.entities.Professor;
import com.example.demo.repositories.ProfessorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProfessorService {

    @Autowired
    private ProfessorRepository professorRepository;

    // Método para listar todos os professores
    public List<Professor> getAllProfessores() {
        return professorRepository.findAll();
    }

    // Método para obter um professor pelo ID
    public Optional<Professor> getProfessorById(Long id) {
        return professorRepository.findById(id);
    }

    // Método para criar um novo professor
    public Professor createProfessor(Professor professor) {
        return professorRepository.save(professor);
    }

    // Método para atualizar um professor
    public Professor updateProfessor(Long id, Professor professorDetails) {
        Optional<Professor> professor = professorRepository.findById(id);
        if (professor.isPresent()) {
            Professor existingProfessor = professor.get();
            existingProfessor.setNome(professorDetails.getNome());
            existingProfessor.setEmail(professorDetails.getEmail());
            existingProfessor.setSenha(professorDetails.getSenha());
            return professorRepository.save(existingProfessor);
        }
        return null;
    }

    // Método para deletar um professor
    public boolean deleteProfessor(Long id) {
        Optional<Professor> professor = professorRepository.findById(id);
        if (professor.isPresent()) {
            professorRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
