package com.example.demo.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Professor")  // Alterado para a tabela "Professor"
public class Professor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_prof;  // Renomeado para id_professor
    private String nome;
    private String email;
    private String senha;

    // Construtor vazio
    public Professor() {
    }

    // Construtor com todos os parâmetros
    public Professor(Long id_prof, String nome, String email, String senha) {
        super();
        this.id_prof = id_prof;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    // Getters
    public Long getId_prof() {
        return id_prof;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    // Setters
    public void setId_prof(Long id_prof) {
        this.id_prof = id_prof;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
