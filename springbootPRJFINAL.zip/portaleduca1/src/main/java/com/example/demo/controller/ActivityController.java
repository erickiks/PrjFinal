package com.example.demo.controller;


import com.example.demo.entities.Activity;
import com.example.demo.services.ActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/activities")
public class ActivityController {

    @Autowired
    private ActivityService activityService;

    // Endpoint para criar uma nova atividade
    @PostMapping("/create")
    public ResponseEntity<Activity> createActivity(
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("link") String link,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam(value = "file", required = false) MultipartFile file) throws IOException {

        // Criando a nova atividade
        Activity activity = new Activity();
        activity.setTitle(title);
        activity.setDescription(description);
        activity.setLink(link);

        // Verificando e armazenando a imagem, caso fornecida
        if (image != null) {
            activity.setImage(image.getBytes());  // Convertendo a imagem para um array de bytes
        }

        // Verificando e armazenando o arquivo, caso fornecido
        if (file != null) {
            activity.setFile(file.getBytes());  // Convertendo o arquivo para um array de bytes
        }

        // Salvando a atividade no banco de dados
        Activity savedActivity = activityService.saveActivity(activity);

        // Retornando a atividade salva com status 201 (created)
        return new ResponseEntity<>(savedActivity, HttpStatus.CREATED);
    }

    // Endpoint para obter todas as atividades (exibidas para o aluno)
    @GetMapping("/all")
    public ResponseEntity<Iterable<Activity>> getAllActivities() {
        Iterable<Activity> activities = activityService.getAllActivities();
        return new ResponseEntity<>(activities, HttpStatus.OK);
    }
}
