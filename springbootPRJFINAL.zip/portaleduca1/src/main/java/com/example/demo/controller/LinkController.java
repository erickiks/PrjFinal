package com.example.demo.controller;

import com.example.demo.entities.Link;
import com.example.demo.services.LinkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/links")
public class LinkController {

    @Autowired
    private LinkService linkService;

    // Endpoint para salvar o link com arquivos
    @PostMapping("/save")
    public ResponseEntity<Link> saveLink(
            @RequestParam String link,
            @RequestParam String description,
            @RequestParam(required = false) MultipartFile image,
            @RequestParam(required = false) MultipartFile file) {
        try {
            // Chama o serviço para salvar o link, imagem e arquivo
            Link savedLink = linkService.saveLink(link, description, image, file);
            // Retorna a resposta com o link salvo e o status HTTP 201 (Criado)
            return new ResponseEntity<>(savedLink, HttpStatus.CREATED);
        } catch (IOException e) {
            // Em caso de erro ao salvar os arquivos, retorna status HTTP 500 (Erro Interno do Servidor)
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Endpoint para obter um link por ID
    @GetMapping("/{id}")
    public ResponseEntity<Link> getLinkById(@PathVariable Long id) {
        // Busca o link no repositório
        Link link = linkService.findLinkById(id);
        if (link != null) {
            return new ResponseEntity<>(link, HttpStatus.OK);
        }
        // Se não encontrar o link, retorna um status HTTP 404 (Não Encontrado)
        return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    }

    // Novo endpoint para obter todos os links
    @GetMapping("/all")
    public ResponseEntity<List<Link>> getAllLinks() {
        List<Link> links = linkService.getAllLinks();
        return new ResponseEntity<>(links, HttpStatus.OK);
    }
}
