package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Aluno;
import com.example.demo.services.AlunoService;

@RestController
@RequestMapping("/login")  // Caminho para Aluno
public class LoginController {

    private final AlunoService alunoService;

    @Autowired
    public LoginController(AlunoService alunoService) {
        this.alunoService = alunoService;
    }

    @PostMapping
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        String email = loginRequest.getEmail();
        String senha = loginRequest.getSenha();

        // Verifica se é um aluno
        Aluno aluno = alunoService.findByEmailAndSenha(email, senha);
        if (aluno != null) {
            return ResponseEntity.ok("Aluno logado com sucesso!");
        }

        return ResponseEntity.status(401).body("Credenciais inválidas.");
    }

    public static class LoginRequest {
        private String email;
        private String senha;

        // Getters and Setters
        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getSenha() {
            return senha;
        }

        public void setSenha(String senha) {
            this.senha = senha;
        }
    }
}
