package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Aluno;  // Alterado para Aluno

public interface AlunoRepository extends JpaRepository<Aluno, Long> {  // Alterado para Aluno

    Aluno findByEmailAndSenha(String email, String senha);  // Método para buscar aluno por email e senha
}
